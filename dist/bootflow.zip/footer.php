<?php

/**
 * The template for displaying the footer
 *
 * Contains the opening of the #site-footer div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Bootflow
 * @since 1.0.0
 */

?>

<!-- FOOTER CODE GOES HERE -->

<?php wp_footer(); ?>

</body>

</html>